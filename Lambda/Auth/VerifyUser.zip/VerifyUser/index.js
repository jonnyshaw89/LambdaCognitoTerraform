console.log('Loading function');

// dependencies
var AWS = require('aws-sdk');

// Get reference to AWS clients
var dynamodb = new AWS.DynamoDB();

var responseSuccess = {
	statusCode: 200,
	headers: {
		'Access-Control-Allow-Origin': '*'
	}
};

var responseError = {
	statusCode: 500,
	headers: {
		'Access-Control-Allow-Origin': '*'
	}
};

function getUser(event, email, fn) {
	dynamodb.getItem({
		TableName: event.stageVariables.auth_db_table,
		Key: {
			email: {
				S: email
			}
		}
	}, function(err, data) {
		if (err) return fn(err);
		else {
			if ('Item' in data) {
				var verified = data.Item.verified.BOOL;
				var verifyToken = null;
				if (!verified) {
					verifyToken = data.Item.verifyToken.S;
				}
				fn(null, verified, verifyToken);
			} else {
				fn(null, null); // User not found
			}
		}
	});
}

function updateUser(event, email, fn) {
	dynamodb.updateItem({
			TableName: event.stageVariables.auth_db_table,
			Key: {
				email: {
					S: email
				}
			},
			AttributeUpdates: {
				verified: {
					Action: 'PUT',
					Value: {
						BOOL: true
					}
				},
				verifyToken: {
					Action: 'DELETE'
				}
			}
		},
		fn);
}

exports.handler = function(event, context) {

	var payload = JSON.parse(event.body);

	var email = payload.email;
	var verifyToken = payload.verify;

	getUser(event, email, function(err, verified, correctToken) {
		if (err) {
			context.fail('Error in getUser: ' + err);
		} else if (verified) {
			console.log('User already verified: ' + email);
			var response = {
				statusCode: 200,
				headers: {
					'Access-Control-Allow-Origin': '*'
				},
				body: JSON.stringify({
					verified: true
				})
			};
			console.log('SUCCESS: ' + JSON.stringify(response));
			context.succeed(response);
		} else if (verifyToken == correctToken) {
			// User verified
			updateUser(event, email, function(err, data) {
				if (err) {
					context.fail('Error in updateUser: ' + err);
				} else {
					console.log('User verified: ' + email);
					var response = {
						statusCode: 200,
						headers: {
							'Access-Control-Allow-Origin': '*'
						},
						body: JSON.stringify({
							verified: true
						})
					};
					console.log('SUCCESS: ' + JSON.stringify(response));
					context.succeed(response);
				}
			});
		} else {
			// Wrong token, not verified
			console.log('User not verified: ' + email);
			var response = {
				statusCode: 200,
				headers: {
					'Access-Control-Allow-Origin': '*'
				},
				body: JSON.stringify({
					verified: false
				})
			};
			console.log('SUCCESS: ' + JSON.stringify(response));
			context.succeed(response);
		}
	});
}
