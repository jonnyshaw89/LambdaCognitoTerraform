console.log('Loading function');

var AWS = require('aws-sdk');

// dependencies
var config = require('./config.json');

var poolData = { UserPoolId : config.USER_POOL_ID,
	ClientId : '4pe2usejqcdmhi0a25jp4b5sh3'
};
var userPool = new AWS.CognitoIdentityServiceProvider;


exports.handler = function(event, context) {

	var payload = JSON.parse(event.body)

	var email = payload.email;
	var clearPassword = payload.password;

	var attributeList = [];

	var dataEmail = {
		Name : 'email',
		Value : email
	};

	//var attributeEmail = new AWSCognito.CognitoIdentityServiceProvider.CognitoUserAttribute(dataEmail);

	//attributeList.push(attributeEmail);

	userPool.signUp(email, clearPassword, attributeList, null, function(err, result){
		if (err) {
			context.fail(new Error(err));
		}
		var cognitoUser = result.user;
		console.log('user ' + JSON.stringify(cognitoUser));
		console.log('user name is ' + cognitoUser.getUsername());
		context.succeed({
			statusCode: responseCode,
			headers: {
			},
			body: JSON.stringify({
				created: true
			})
		});
	});
}
